package at.ac.codingcookies.ccc2020;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import static at.ac.codingcookies.ccc2020.IOTools.*;

public class Main {
    private static String INPUT_FILE= "";

    public static void main(String[] args) {

        /*
        List<Double> ds = IOTools.readInts("test.txt");
        System.out.println("ds = " + ds);

        String[] strings = new String[]{",","Hello","hi"};
        IOTools.saveStrings(new LinkedList<String>(Arrays.asList(strings)));
         */

    }

    public void myMethod() {

    }
}
