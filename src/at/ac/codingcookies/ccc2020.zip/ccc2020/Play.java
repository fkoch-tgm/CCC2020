package at.ac.codingcookies.ccc2020;

public class Play {
    private int id;
    private int score;

    public Play(int id, int score) {
        this.id = id;
        this.score = score;
    }

    public int getId() {
        return id;
    }

    public int getScore() {
        return score;
    }
}