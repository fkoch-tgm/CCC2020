package at.ac.codingcookies.ccc2020;

/**
 * TODO doc
 *
 * @author Felix Koch
 * @version 2020-10-30
 */
public class Player {
    int id;
    int wins;
    int points;

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void changePoints(int points) {
        this.points += points;
    }

    public int getId() {
        return id;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Player(int id, int wins) {
        this.id = id;
        this.wins = wins;
        this.points = 0;
    }

    public String toString() {
        return id + " " + points;
    }
}
